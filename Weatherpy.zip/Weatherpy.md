

```python
# Import Dependencies
import json
import seaborn as sns
import requests as req
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import random
from citipy import citipy
import time
```


```python
# Save config information
api_key = "600074174b9afc5bc6d2270aa7f2edd3"
url = "http://api.openweathermap.org/data/2.5/weather?"
```


```python
# Randomly select at least 500 unique cities based on latitude and longitude
# latitude range from -90 to 90
# longitude range from -180 to 180

# look at cities.py in the activities

# get the sample size and create blank lists for lat and lon
sample_size = int(input("How many cities would you like to sample? "))
lat = []
lon = []
cities = []

# fill the random lats and lons
for i in range(0, sample_size):
    lat.append(random.uniform(-90, 90))
    lon.append(random.uniform(-180, 180))
    
for i in range(len(lat)):
    cities.append(citipy.nearest_city(lat[i], lon[i]).city_name)


```

    How many cities would you like to sample? 500
    


```python
# Perform a weather check on cities using API calls
# Include a print log with the city number, city name, and URL
weather_data = []
count = 1
for city in cities:
    # Build query URL
    query_url = url + "appid=" + api_key + "&q=" + city + "&units=imperial"

    # Get weather data
    weather_response = req.get(query_url).json()
    weather_data.append(weather_response)

    print("City Number: " + str(count) + " City Name: " + city + " URL: " + query_url)
    count += 1
    sleep = 1
    
# Extract interesting data from responses
lat_data = [data.get("coord").get("lat") for data in weather_data]
temp_data = [data.get("main").get("temp") for data in weather_data]
hum_data = [data.get("main").get("humidity") for data in weather_data]
cld_data = [data.get("clouds").get("all") for data in weather_data]
wind_data = [data.get("wind").get("speed") for data in weather_data]



```

    City Number: 1 City Name: klaksvik URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=klaksvik&units=imperial
    City Number: 2 City Name: tuatapere URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tuatapere&units=imperial
    City Number: 3 City Name: busselton URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=busselton&units=imperial
    City Number: 4 City Name: tuktoyaktuk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tuktoyaktuk&units=imperial
    City Number: 5 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 6 City Name: bredasdorp URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bredasdorp&units=imperial
    City Number: 7 City Name: petropavlovsk-kamchatskiy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=petropavlovsk-kamchatskiy&units=imperial
    City Number: 8 City Name: barentsburg URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=barentsburg&units=imperial
    City Number: 9 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 10 City Name: naryan-mar URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=naryan-mar&units=imperial
    City Number: 11 City Name: samarai URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=samarai&units=imperial
    City Number: 12 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 13 City Name: guangyuan URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=guangyuan&units=imperial
    City Number: 14 City Name: lebu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=lebu&units=imperial
    City Number: 15 City Name: mugur-aksy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mugur-aksy&units=imperial
    City Number: 16 City Name: mataura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mataura&units=imperial
    City Number: 17 City Name: upernavik URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=upernavik&units=imperial
    City Number: 18 City Name: clyde river URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=clyde river&units=imperial
    City Number: 19 City Name: solnechnyy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=solnechnyy&units=imperial
    City Number: 20 City Name: zaria URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=zaria&units=imperial
    City Number: 21 City Name: berdigestyakh URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=berdigestyakh&units=imperial
    City Number: 22 City Name: mataura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mataura&units=imperial
    City Number: 23 City Name: atuona URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=atuona&units=imperial
    City Number: 24 City Name: puerto varas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=puerto varas&units=imperial
    City Number: 25 City Name: lorengau URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=lorengau&units=imperial
    City Number: 26 City Name: potiskum URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=potiskum&units=imperial
    City Number: 27 City Name: lebu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=lebu&units=imperial
    City Number: 28 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 29 City Name: maloshuyka URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=maloshuyka&units=imperial
    City Number: 30 City Name: turayf URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=turayf&units=imperial
    City Number: 31 City Name: albany URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=albany&units=imperial
    City Number: 32 City Name: chirongui URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=chirongui&units=imperial
    City Number: 33 City Name: libenge URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=libenge&units=imperial
    City Number: 34 City Name: barentsburg URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=barentsburg&units=imperial
    City Number: 35 City Name: ponta do sol URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ponta do sol&units=imperial
    City Number: 36 City Name: santa maria del oro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=santa maria del oro&units=imperial
    City Number: 37 City Name: krasnoyarsk-45 URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=krasnoyarsk-45&units=imperial
    City Number: 38 City Name: taoudenni URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=taoudenni&units=imperial
    City Number: 39 City Name: tuktoyaktuk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tuktoyaktuk&units=imperial
    City Number: 40 City Name: necochea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=necochea&units=imperial
    City Number: 41 City Name: ciudad bolivar URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ciudad bolivar&units=imperial
    City Number: 42 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 43 City Name: cuenca URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cuenca&units=imperial
    City Number: 44 City Name: pevek URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=pevek&units=imperial
    City Number: 45 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 46 City Name: chuy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=chuy&units=imperial
    City Number: 47 City Name: khatanga URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=khatanga&units=imperial
    City Number: 48 City Name: new norfolk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=new norfolk&units=imperial
    City Number: 49 City Name: waingapu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=waingapu&units=imperial
    City Number: 50 City Name: torbay URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=torbay&units=imperial
    City Number: 51 City Name: kununurra URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kununurra&units=imperial
    City Number: 52 City Name: samarai URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=samarai&units=imperial
    City Number: 53 City Name: markova URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=markova&units=imperial
    City Number: 54 City Name: new norfolk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=new norfolk&units=imperial
    City Number: 55 City Name: mataura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mataura&units=imperial
    City Number: 56 City Name: kon tum URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kon tum&units=imperial
    City Number: 57 City Name: imbituba URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=imbituba&units=imperial
    City Number: 58 City Name: tuktoyaktuk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tuktoyaktuk&units=imperial
    City Number: 59 City Name: belushya guba URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=belushya guba&units=imperial
    City Number: 60 City Name: port alfred URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=port alfred&units=imperial
    City Number: 61 City Name: mataura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mataura&units=imperial
    City Number: 62 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 63 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 64 City Name: constitucion URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=constitucion&units=imperial
    City Number: 65 City Name: luebo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=luebo&units=imperial
    City Number: 66 City Name: airai URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=airai&units=imperial
    City Number: 67 City Name: kenai URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kenai&units=imperial
    City Number: 68 City Name: rocha URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rocha&units=imperial
    City Number: 69 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 70 City Name: atar URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=atar&units=imperial
    City Number: 71 City Name: illoqqortoormiut URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=illoqqortoormiut&units=imperial
    City Number: 72 City Name: cruzilia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cruzilia&units=imperial
    City Number: 73 City Name: kaeo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kaeo&units=imperial
    City Number: 74 City Name: barrow URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=barrow&units=imperial
    City Number: 75 City Name: birjand URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=birjand&units=imperial
    City Number: 76 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 77 City Name: puerto ayora URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=puerto ayora&units=imperial
    City Number: 78 City Name: bambous virieux URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bambous virieux&units=imperial
    City Number: 79 City Name: pudozh URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=pudozh&units=imperial
    City Number: 80 City Name: carauari URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=carauari&units=imperial
    City Number: 81 City Name: teguise URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=teguise&units=imperial
    City Number: 82 City Name: korla URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=korla&units=imperial
    City Number: 83 City Name: bima URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bima&units=imperial
    City Number: 84 City Name: kampot URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kampot&units=imperial
    City Number: 85 City Name: taolanaro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=taolanaro&units=imperial
    City Number: 86 City Name: te anau URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=te anau&units=imperial
    City Number: 87 City Name: puerto colombia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=puerto colombia&units=imperial
    City Number: 88 City Name: swan hill URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=swan hill&units=imperial
    City Number: 89 City Name: georgetown URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=georgetown&units=imperial
    City Number: 90 City Name: kaitangata URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kaitangata&units=imperial
    City Number: 91 City Name: jamestown URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=jamestown&units=imperial
    City Number: 92 City Name: qaanaaq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=qaanaaq&units=imperial
    City Number: 93 City Name: busselton URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=busselton&units=imperial
    City Number: 94 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 95 City Name: taolanaro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=taolanaro&units=imperial
    City Number: 96 City Name: saint anthony URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saint anthony&units=imperial
    City Number: 97 City Name: busselton URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=busselton&units=imperial
    City Number: 98 City Name: belushya guba URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=belushya guba&units=imperial
    City Number: 99 City Name: belushya guba URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=belushya guba&units=imperial
    City Number: 100 City Name: nikolskoye URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nikolskoye&units=imperial
    City Number: 101 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 102 City Name: touros URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=touros&units=imperial
    City Number: 103 City Name: athabasca URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=athabasca&units=imperial
    City Number: 104 City Name: vaitupu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=vaitupu&units=imperial
    City Number: 105 City Name: carnarvon URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=carnarvon&units=imperial
    City Number: 106 City Name: mukhen URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mukhen&units=imperial
    City Number: 107 City Name: bandarbeyla URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bandarbeyla&units=imperial
    City Number: 108 City Name: east london URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=east london&units=imperial
    City Number: 109 City Name: saint-philippe URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saint-philippe&units=imperial
    City Number: 110 City Name: salinopolis URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=salinopolis&units=imperial
    City Number: 111 City Name: mataura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mataura&units=imperial
    City Number: 112 City Name: darque URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=darque&units=imperial
    City Number: 113 City Name: veraval URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=veraval&units=imperial
    City Number: 114 City Name: phuket URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=phuket&units=imperial
    City Number: 115 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 116 City Name: tiksi URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tiksi&units=imperial
    City Number: 117 City Name: leningradskiy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=leningradskiy&units=imperial
    City Number: 118 City Name: tigre URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tigre&units=imperial
    City Number: 119 City Name: morlenbach URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=morlenbach&units=imperial
    City Number: 120 City Name: atuona URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=atuona&units=imperial
    City Number: 121 City Name: inuvik URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=inuvik&units=imperial
    City Number: 122 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 123 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 124 City Name: touros URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=touros&units=imperial
    City Number: 125 City Name: maloy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=maloy&units=imperial
    City Number: 126 City Name: mataura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mataura&units=imperial
    City Number: 127 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 128 City Name: lebu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=lebu&units=imperial
    City Number: 129 City Name: westport URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=westport&units=imperial
    City Number: 130 City Name: busselton URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=busselton&units=imperial
    City Number: 131 City Name: saint-leu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saint-leu&units=imperial
    City Number: 132 City Name: shenjiamen URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=shenjiamen&units=imperial
    City Number: 133 City Name: san quintin URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=san quintin&units=imperial
    City Number: 134 City Name: castro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=castro&units=imperial
    City Number: 135 City Name: constitucion URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=constitucion&units=imperial
    City Number: 136 City Name: touros URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=touros&units=imperial
    City Number: 137 City Name: asau URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=asau&units=imperial
    City Number: 138 City Name: hobart URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hobart&units=imperial
    City Number: 139 City Name: saleaula URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saleaula&units=imperial
    City Number: 140 City Name: fangshan URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=fangshan&units=imperial
    City Number: 141 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 142 City Name: taolanaro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=taolanaro&units=imperial
    City Number: 143 City Name: san patricio URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=san patricio&units=imperial
    City Number: 144 City Name: yellowknife URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=yellowknife&units=imperial
    City Number: 145 City Name: taolanaro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=taolanaro&units=imperial
    City Number: 146 City Name: kedrovyy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kedrovyy&units=imperial
    City Number: 147 City Name: albany URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=albany&units=imperial
    City Number: 148 City Name: airai URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=airai&units=imperial
    City Number: 149 City Name: tuatapere URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tuatapere&units=imperial
    City Number: 150 City Name: kongolo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kongolo&units=imperial
    City Number: 151 City Name: castro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=castro&units=imperial
    City Number: 152 City Name: new norfolk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=new norfolk&units=imperial
    City Number: 153 City Name: komsomolskiy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=komsomolskiy&units=imperial
    City Number: 154 City Name: sur URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=sur&units=imperial
    City Number: 155 City Name: richards bay URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=richards bay&units=imperial
    City Number: 156 City Name: hermanus URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hermanus&units=imperial
    City Number: 157 City Name: kaele URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kaele&units=imperial
    City Number: 158 City Name: barrow URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=barrow&units=imperial
    City Number: 159 City Name: saint-francois URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saint-francois&units=imperial
    City Number: 160 City Name: mangai URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mangai&units=imperial
    City Number: 161 City Name: bubaque URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bubaque&units=imperial
    City Number: 162 City Name: belaya gora URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=belaya gora&units=imperial
    City Number: 163 City Name: albany URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=albany&units=imperial
    City Number: 164 City Name: sitka URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=sitka&units=imperial
    City Number: 165 City Name: bolungarvik URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bolungarvik&units=imperial
    City Number: 166 City Name: verkhnevilyuysk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=verkhnevilyuysk&units=imperial
    City Number: 167 City Name: nikolskoye URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nikolskoye&units=imperial
    City Number: 168 City Name: general roca URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=general roca&units=imperial
    City Number: 169 City Name: kargasok URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kargasok&units=imperial
    City Number: 170 City Name: east london URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=east london&units=imperial
    City Number: 171 City Name: ishigaki URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ishigaki&units=imperial
    City Number: 172 City Name: dingle URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=dingle&units=imperial
    City Number: 173 City Name: key largo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=key largo&units=imperial
    City Number: 174 City Name: taoudenni URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=taoudenni&units=imperial
    City Number: 175 City Name: jamestown URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=jamestown&units=imperial
    City Number: 176 City Name: saskylakh URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saskylakh&units=imperial
    City Number: 177 City Name: san patricio URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=san patricio&units=imperial
    City Number: 178 City Name: puerto ayora URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=puerto ayora&units=imperial
    City Number: 179 City Name: buchanan URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=buchanan&units=imperial
    City Number: 180 City Name: hithadhoo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hithadhoo&units=imperial
    City Number: 181 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 182 City Name: iracoubo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=iracoubo&units=imperial
    City Number: 183 City Name: santa vitoria do palmar URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=santa vitoria do palmar&units=imperial
    City Number: 184 City Name: chilca URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=chilca&units=imperial
    City Number: 185 City Name: katsuura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=katsuura&units=imperial
    City Number: 186 City Name: samarai URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=samarai&units=imperial
    City Number: 187 City Name: arraial do cabo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=arraial do cabo&units=imperial
    City Number: 188 City Name: narsaq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=narsaq&units=imperial
    City Number: 189 City Name: saint george URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saint george&units=imperial
    City Number: 190 City Name: touros URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=touros&units=imperial
    City Number: 191 City Name: tsihombe URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tsihombe&units=imperial
    City Number: 192 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 193 City Name: upernavik URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=upernavik&units=imperial
    City Number: 194 City Name: belushya guba URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=belushya guba&units=imperial
    City Number: 195 City Name: butaritari URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=butaritari&units=imperial
    City Number: 196 City Name: hilo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hilo&units=imperial
    City Number: 197 City Name: dawei URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=dawei&units=imperial
    City Number: 198 City Name: kodiak URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kodiak&units=imperial
    City Number: 199 City Name: balykshi URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=balykshi&units=imperial
    City Number: 200 City Name: marzuq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=marzuq&units=imperial
    City Number: 201 City Name: honiara URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=honiara&units=imperial
    City Number: 202 City Name: carutapera URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=carutapera&units=imperial
    City Number: 203 City Name: veraval URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=veraval&units=imperial
    City Number: 204 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 205 City Name: tombouctou URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tombouctou&units=imperial
    City Number: 206 City Name: tiksi URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tiksi&units=imperial
    City Number: 207 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 208 City Name: jaguaribe URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=jaguaribe&units=imperial
    City Number: 209 City Name: fallon URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=fallon&units=imperial
    City Number: 210 City Name: listvyanskiy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=listvyanskiy&units=imperial
    City Number: 211 City Name: fengrun URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=fengrun&units=imperial
    City Number: 212 City Name: sioux lookout URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=sioux lookout&units=imperial
    City Number: 213 City Name: nikolskoye URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nikolskoye&units=imperial
    City Number: 214 City Name: ahipara URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ahipara&units=imperial
    City Number: 215 City Name: arraial do cabo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=arraial do cabo&units=imperial
    City Number: 216 City Name: itapirapua URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=itapirapua&units=imperial
    City Number: 217 City Name: kununurra URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kununurra&units=imperial
    City Number: 218 City Name: shitanjing URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=shitanjing&units=imperial
    City Number: 219 City Name: dikson URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=dikson&units=imperial
    City Number: 220 City Name: mehamn URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mehamn&units=imperial
    City Number: 221 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 222 City Name: hithadhoo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hithadhoo&units=imperial
    City Number: 223 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 224 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 225 City Name: albany URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=albany&units=imperial
    City Number: 226 City Name: souillac URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=souillac&units=imperial
    City Number: 227 City Name: belushya guba URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=belushya guba&units=imperial
    City Number: 228 City Name: ketchikan URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ketchikan&units=imperial
    City Number: 229 City Name: khatanga URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=khatanga&units=imperial
    City Number: 230 City Name: port alfred URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=port alfred&units=imperial
    City Number: 231 City Name: east london URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=east london&units=imperial
    City Number: 232 City Name: bengkulu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bengkulu&units=imperial
    City Number: 233 City Name: tuktoyaktuk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tuktoyaktuk&units=imperial
    City Number: 234 City Name: luangwa URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=luangwa&units=imperial
    City Number: 235 City Name: fortuna URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=fortuna&units=imperial
    City Number: 236 City Name: kavaratti URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kavaratti&units=imperial
    City Number: 237 City Name: bilibino URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bilibino&units=imperial
    City Number: 238 City Name: salinas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=salinas&units=imperial
    City Number: 239 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 240 City Name: hithadhoo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hithadhoo&units=imperial
    City Number: 241 City Name: atuona URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=atuona&units=imperial
    City Number: 242 City Name: labuan URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=labuan&units=imperial
    City Number: 243 City Name: lompoc URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=lompoc&units=imperial
    City Number: 244 City Name: macedonia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=macedonia&units=imperial
    City Number: 245 City Name: bengkulu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bengkulu&units=imperial
    City Number: 246 City Name: skjervoy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=skjervoy&units=imperial
    City Number: 247 City Name: muscat URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=muscat&units=imperial
    City Number: 248 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 249 City Name: aklavik URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=aklavik&units=imperial
    City Number: 250 City Name: zdvinsk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=zdvinsk&units=imperial
    City Number: 251 City Name: sentyabrskiy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=sentyabrskiy&units=imperial
    City Number: 252 City Name: bethel URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bethel&units=imperial
    City Number: 253 City Name: port alfred URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=port alfred&units=imperial
    City Number: 254 City Name: port alfred URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=port alfred&units=imperial
    City Number: 255 City Name: fairbanks URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=fairbanks&units=imperial
    City Number: 256 City Name: sioux lookout URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=sioux lookout&units=imperial
    City Number: 257 City Name: narsaq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=narsaq&units=imperial
    City Number: 258 City Name: bluff URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bluff&units=imperial
    City Number: 259 City Name: jamestown URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=jamestown&units=imperial
    City Number: 260 City Name: albany URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=albany&units=imperial
    City Number: 261 City Name: mugur-aksy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mugur-aksy&units=imperial
    City Number: 262 City Name: saskylakh URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saskylakh&units=imperial
    City Number: 263 City Name: dikson URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=dikson&units=imperial
    City Number: 264 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 265 City Name: bay roberts URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bay roberts&units=imperial
    City Number: 266 City Name: bredasdorp URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bredasdorp&units=imperial
    City Number: 267 City Name: isangel URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=isangel&units=imperial
    City Number: 268 City Name: castro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=castro&units=imperial
    City Number: 269 City Name: lorengau URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=lorengau&units=imperial
    City Number: 270 City Name: taoudenni URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=taoudenni&units=imperial
    City Number: 271 City Name: bredasdorp URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bredasdorp&units=imperial
    City Number: 272 City Name: tiarei URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tiarei&units=imperial
    City Number: 273 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 274 City Name: nelson bay URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nelson bay&units=imperial
    City Number: 275 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 276 City Name: college URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=college&units=imperial
    City Number: 277 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 278 City Name: kalaleh URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kalaleh&units=imperial
    City Number: 279 City Name: cidreira URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cidreira&units=imperial
    City Number: 280 City Name: mys shmidta URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mys shmidta&units=imperial
    City Number: 281 City Name: charcas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=charcas&units=imperial
    City Number: 282 City Name: umzimvubu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=umzimvubu&units=imperial
    City Number: 283 City Name: vaini URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=vaini&units=imperial
    City Number: 284 City Name: woodway URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=woodway&units=imperial
    City Number: 285 City Name: atuona URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=atuona&units=imperial
    City Number: 286 City Name: kavieng URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kavieng&units=imperial
    City Number: 287 City Name: saint austell URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saint austell&units=imperial
    City Number: 288 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 289 City Name: mehtar lam URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mehtar lam&units=imperial
    City Number: 290 City Name: portland URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=portland&units=imperial
    City Number: 291 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 292 City Name: muncar URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=muncar&units=imperial
    City Number: 293 City Name: cedeno URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cedeno&units=imperial
    City Number: 294 City Name: talnakh URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=talnakh&units=imperial
    City Number: 295 City Name: auki URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=auki&units=imperial
    City Number: 296 City Name: te anau URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=te anau&units=imperial
    City Number: 297 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 298 City Name: saskylakh URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saskylakh&units=imperial
    City Number: 299 City Name: yellowknife URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=yellowknife&units=imperial
    City Number: 300 City Name: port alfred URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=port alfred&units=imperial
    City Number: 301 City Name: hobart URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hobart&units=imperial
    City Number: 302 City Name: dvinskoy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=dvinskoy&units=imperial
    City Number: 303 City Name: pangai URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=pangai&units=imperial
    City Number: 304 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 305 City Name: saldanha URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saldanha&units=imperial
    City Number: 306 City Name: kapaa URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kapaa&units=imperial
    City Number: 307 City Name: pevek URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=pevek&units=imperial
    City Number: 308 City Name: mataura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mataura&units=imperial
    City Number: 309 City Name: yellowknife URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=yellowknife&units=imperial
    City Number: 310 City Name: nouadhibou URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nouadhibou&units=imperial
    City Number: 311 City Name: kahului URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kahului&units=imperial
    City Number: 312 City Name: bredasdorp URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bredasdorp&units=imperial
    City Number: 313 City Name: ciurila URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ciurila&units=imperial
    City Number: 314 City Name: ariquemes URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ariquemes&units=imperial
    City Number: 315 City Name: nome URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nome&units=imperial
    City Number: 316 City Name: jamestown URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=jamestown&units=imperial
    City Number: 317 City Name: yulara URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=yulara&units=imperial
    City Number: 318 City Name: barrow URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=barrow&units=imperial
    City Number: 319 City Name: aloleng URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=aloleng&units=imperial
    City Number: 320 City Name: claresholm URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=claresholm&units=imperial
    City Number: 321 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 322 City Name: caravelas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=caravelas&units=imperial
    City Number: 323 City Name: rio grande URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rio grande&units=imperial
    City Number: 324 City Name: vila franca do campo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=vila franca do campo&units=imperial
    City Number: 325 City Name: husavik URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=husavik&units=imperial
    City Number: 326 City Name: lebu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=lebu&units=imperial
    City Number: 327 City Name: kapaa URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kapaa&units=imperial
    City Number: 328 City Name: nikolskoye URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nikolskoye&units=imperial
    City Number: 329 City Name: shimoda URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=shimoda&units=imperial
    City Number: 330 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 331 City Name: sitka URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=sitka&units=imperial
    City Number: 332 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 333 City Name: camargo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=camargo&units=imperial
    City Number: 334 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 335 City Name: kapaa URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kapaa&units=imperial
    City Number: 336 City Name: shawville URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=shawville&units=imperial
    City Number: 337 City Name: fukue URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=fukue&units=imperial
    City Number: 338 City Name: pokhara URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=pokhara&units=imperial
    City Number: 339 City Name: illoqqortoormiut URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=illoqqortoormiut&units=imperial
    City Number: 340 City Name: new norfolk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=new norfolk&units=imperial
    City Number: 341 City Name: port lincoln URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=port lincoln&units=imperial
    City Number: 342 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 343 City Name: butaritari URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=butaritari&units=imperial
    City Number: 344 City Name: port elizabeth URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=port elizabeth&units=imperial
    City Number: 345 City Name: latung URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=latung&units=imperial
    City Number: 346 City Name: hamilton URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hamilton&units=imperial
    City Number: 347 City Name: hobart URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hobart&units=imperial
    City Number: 348 City Name: zhuhai URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=zhuhai&units=imperial
    City Number: 349 City Name: saskylakh URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saskylakh&units=imperial
    City Number: 350 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 351 City Name: morlaix URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=morlaix&units=imperial
    City Number: 352 City Name: rawson URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rawson&units=imperial
    City Number: 353 City Name: qaanaaq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=qaanaaq&units=imperial
    City Number: 354 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 355 City Name: eirunepe URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=eirunepe&units=imperial
    City Number: 356 City Name: nikolskoye URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nikolskoye&units=imperial
    City Number: 357 City Name: komsomolets URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=komsomolets&units=imperial
    City Number: 358 City Name: ubinskoye URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ubinskoye&units=imperial
    City Number: 359 City Name: wagar URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=wagar&units=imperial
    City Number: 360 City Name: kuito URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kuito&units=imperial
    City Number: 361 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 362 City Name: busselton URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=busselton&units=imperial
    City Number: 363 City Name: taolanaro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=taolanaro&units=imperial
    City Number: 364 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 365 City Name: umzimvubu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=umzimvubu&units=imperial
    City Number: 366 City Name: mys shmidta URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mys shmidta&units=imperial
    City Number: 367 City Name: tasiilaq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tasiilaq&units=imperial
    City Number: 368 City Name: qaanaaq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=qaanaaq&units=imperial
    City Number: 369 City Name: honnali URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=honnali&units=imperial
    City Number: 370 City Name: vaini URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=vaini&units=imperial
    City Number: 371 City Name: hambantota URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hambantota&units=imperial
    City Number: 372 City Name: bandipur URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bandipur&units=imperial
    City Number: 373 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 374 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 375 City Name: pontianak URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=pontianak&units=imperial
    City Number: 376 City Name: geraldton URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=geraldton&units=imperial
    City Number: 377 City Name: caravelas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=caravelas&units=imperial
    City Number: 378 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 379 City Name: atuona URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=atuona&units=imperial
    City Number: 380 City Name: grand river south east URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=grand river south east&units=imperial
    City Number: 381 City Name: vaitape URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=vaitape&units=imperial
    City Number: 382 City Name: kapaa URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kapaa&units=imperial
    City Number: 383 City Name: anage URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=anage&units=imperial
    City Number: 384 City Name: torbay URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=torbay&units=imperial
    City Number: 385 City Name: arraial do cabo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=arraial do cabo&units=imperial
    City Number: 386 City Name: mentok URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mentok&units=imperial
    City Number: 387 City Name: komsomolskiy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=komsomolskiy&units=imperial
    City Number: 388 City Name: ferrandina URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ferrandina&units=imperial
    City Number: 389 City Name: ribeira grande URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ribeira grande&units=imperial
    City Number: 390 City Name: lebu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=lebu&units=imperial
    City Number: 391 City Name: fortuna URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=fortuna&units=imperial
    City Number: 392 City Name: east london URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=east london&units=imperial
    City Number: 393 City Name: dali URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=dali&units=imperial
    City Number: 394 City Name: nam som URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nam som&units=imperial
    City Number: 395 City Name: varkaus URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=varkaus&units=imperial
    City Number: 396 City Name: bengkulu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bengkulu&units=imperial
    City Number: 397 City Name: corowa URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=corowa&units=imperial
    City Number: 398 City Name: yumen URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=yumen&units=imperial
    City Number: 399 City Name: los llanos de aridane URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=los llanos de aridane&units=imperial
    City Number: 400 City Name: severo-kurilsk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=severo-kurilsk&units=imperial
    City Number: 401 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 402 City Name: nantucket URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nantucket&units=imperial
    City Number: 403 City Name: qaanaaq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=qaanaaq&units=imperial
    City Number: 404 City Name: chuy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=chuy&units=imperial
    City Number: 405 City Name: chokurdakh URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=chokurdakh&units=imperial
    City Number: 406 City Name: asau URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=asau&units=imperial
    City Number: 407 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 408 City Name: nam tha URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=nam tha&units=imperial
    City Number: 409 City Name: yellowknife URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=yellowknife&units=imperial
    City Number: 410 City Name: beloha URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=beloha&units=imperial
    City Number: 411 City Name: akyab URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=akyab&units=imperial
    City Number: 412 City Name: thompson URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=thompson&units=imperial
    City Number: 413 City Name: provideniya URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=provideniya&units=imperial
    City Number: 414 City Name: saldanha URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saldanha&units=imperial
    City Number: 415 City Name: albany URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=albany&units=imperial
    City Number: 416 City Name: luderitz URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=luderitz&units=imperial
    City Number: 417 City Name: castro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=castro&units=imperial
    City Number: 418 City Name: dingle URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=dingle&units=imperial
    City Number: 419 City Name: jizan URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=jizan&units=imperial
    City Number: 420 City Name: rapid city URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rapid city&units=imperial
    City Number: 421 City Name: hibbing URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hibbing&units=imperial
    City Number: 422 City Name: guerrero negro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=guerrero negro&units=imperial
    City Number: 423 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 424 City Name: sakakah URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=sakakah&units=imperial
    City Number: 425 City Name: sentyabrskiy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=sentyabrskiy&units=imperial
    City Number: 426 City Name: zhigansk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=zhigansk&units=imperial
    City Number: 427 City Name: yellowknife URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=yellowknife&units=imperial
    City Number: 428 City Name: trinidad URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=trinidad&units=imperial
    City Number: 429 City Name: hermanus URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hermanus&units=imperial
    City Number: 430 City Name: thompson URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=thompson&units=imperial
    City Number: 431 City Name: ngunguru URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ngunguru&units=imperial
    City Number: 432 City Name: fortuna URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=fortuna&units=imperial
    City Number: 433 City Name: avarua URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=avarua&units=imperial
    City Number: 434 City Name: grand gaube URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=grand gaube&units=imperial
    City Number: 435 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 436 City Name: bredasdorp URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bredasdorp&units=imperial
    City Number: 437 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 438 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 439 City Name: jamestown URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=jamestown&units=imperial
    City Number: 440 City Name: new norfolk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=new norfolk&units=imperial
    City Number: 441 City Name: atuona URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=atuona&units=imperial
    City Number: 442 City Name: naro URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=naro&units=imperial
    City Number: 443 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 444 City Name: saint-philippe URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=saint-philippe&units=imperial
    City Number: 445 City Name: liaozhong URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=liaozhong&units=imperial
    City Number: 446 City Name: dali URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=dali&units=imperial
    City Number: 447 City Name: tautira URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tautira&units=imperial
    City Number: 448 City Name: katsuura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=katsuura&units=imperial
    City Number: 449 City Name: avarua URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=avarua&units=imperial
    City Number: 450 City Name: kaitangata URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kaitangata&units=imperial
    City Number: 451 City Name: new norfolk URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=new norfolk&units=imperial
    City Number: 452 City Name: kandri URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=kandri&units=imperial
    City Number: 453 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 454 City Name: narsaq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=narsaq&units=imperial
    City Number: 455 City Name: izhma URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=izhma&units=imperial
    City Number: 456 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 457 City Name: bluff URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bluff&units=imperial
    City Number: 458 City Name: narsaq URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=narsaq&units=imperial
    City Number: 459 City Name: pittsburg URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=pittsburg&units=imperial
    City Number: 460 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 461 City Name: lodwar URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=lodwar&units=imperial
    City Number: 462 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 463 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 464 City Name: talara URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=talara&units=imperial
    City Number: 465 City Name: bolungarvik URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bolungarvik&units=imperial
    City Number: 466 City Name: barawe URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=barawe&units=imperial
    City Number: 467 City Name: rocha URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rocha&units=imperial
    City Number: 468 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 469 City Name: mataura URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mataura&units=imperial
    City Number: 470 City Name: pevek URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=pevek&units=imperial
    City Number: 471 City Name: mahebourg URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=mahebourg&units=imperial
    City Number: 472 City Name: san vicente URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=san vicente&units=imperial
    City Number: 473 City Name: cape town URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=cape town&units=imperial
    City Number: 474 City Name: rikitea URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=rikitea&units=imperial
    City Number: 475 City Name: luderitz URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=luderitz&units=imperial
    City Number: 476 City Name: yima URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=yima&units=imperial
    City Number: 477 City Name: balaghat URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=balaghat&units=imperial
    City Number: 478 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 479 City Name: komsomolskiy URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=komsomolskiy&units=imperial
    City Number: 480 City Name: arauca URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=arauca&units=imperial
    City Number: 481 City Name: tidore URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=tidore&units=imperial
    City Number: 482 City Name: jamestown URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=jamestown&units=imperial
    City Number: 483 City Name: naze URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=naze&units=imperial
    City Number: 484 City Name: la orilla URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=la orilla&units=imperial
    City Number: 485 City Name: anadyr URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=anadyr&units=imperial
    City Number: 486 City Name: hilo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=hilo&units=imperial
    City Number: 487 City Name: ginda URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ginda&units=imperial
    City Number: 488 City Name: busselton URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=busselton&units=imperial
    City Number: 489 City Name: geraldton URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=geraldton&units=imperial
    City Number: 490 City Name: resistencia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=resistencia&units=imperial
    City Number: 491 City Name: arraial do cabo URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=arraial do cabo&units=imperial
    City Number: 492 City Name: east london URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=east london&units=imperial
    City Number: 493 City Name: basti URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=basti&units=imperial
    City Number: 494 City Name: jinji URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=jinji&units=imperial
    City Number: 495 City Name: barrow URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=barrow&units=imperial
    City Number: 496 City Name: ushuaia URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=ushuaia&units=imperial
    City Number: 497 City Name: punta arenas URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=punta arenas&units=imperial
    City Number: 498 City Name: vaitupu URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=vaitupu&units=imperial
    City Number: 499 City Name: atuona URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=atuona&units=imperial
    City Number: 500 City Name: bacolod URL: http://api.openweathermap.org/data/2.5/weather?appid=600074174b9afc5bc6d2270aa7f2edd3&q=bacolod&units=imperial
    


```python
# Build Scatter Plot of Temp (F) vs. Latitude
temp_df = pd.DataFrame({"lat": lat_data, "temp": temp_data})

plt.scatter(temp_df["lat"], temp_df["temp"], marker="o")

# Incorporate the other graph properties
plt.title("City Latitude vs. Temperature (F)")
plt.ylabel("Temperature (F)")
plt.xlabel("Latitutde")
plt.grid(True)

# Save the figure
plt.savefig("Latitude_vs_Temp.png")

# Show plot
plt.show()
```


![png](output_4_0.png)



```python
# Build Scatter Plot of Humidity (%) vs. Latitude
hum_df = pd.DataFrame({"lat": lat_data, "humidity": hum_data})

plt.scatter(hum_df["lat"], hum_df["humidity"], marker="o")

# Incorporate the other graph properties
plt.title("City Latitude vs. Humidity (%)")
plt.ylabel("Humidity (%)")
plt.xlabel("Latitutde")
plt.grid(True)

# Save the figure
plt.savefig("Latitude_vs_Humidity.png")

# Show plot
plt.show()
```


![png](output_5_0.png)



```python
# Build Scatter Plot of Cloudiness (%) vs. Latitude
cld_df = pd.DataFrame({"lat": lat_data, "cloudiness": cld_data})

plt.scatter(cld_df["lat"], cld_df["cloudiness"], marker="o")

# Incorporate the other graph properties
plt.title("City Latitude vs. Cloudiness (%)")
plt.ylabel("Cloudiness (%)")
plt.xlabel("Latitutde")
plt.grid(True)

# Save the figure
plt.savefig("Latitude_vs_Cloudiness.png")

# Show plot
plt.show()
```


![png](output_6_0.png)



```python
# Build Scatter Plot of Wind Speed (mph) vs. Latitude
wind_df = pd.DataFrame({"lat": lat_data, "wind": wind_data})

plt.scatter(wind_df["lat"], wind_df["wind"], marker="o")

# Incorporate the other graph properties
plt.title("City Latitude vs. Windspeed (mph)")
plt.ylabel("Windspeed (mph)")
plt.xlabel("Latitutde")
plt.grid(True)

# Save the figure
plt.savefig("Latitude_vs_Windspeed.png")

# Show plot
plt.show()
```


![png](output_7_0.png)



```python
# Save CSV of all Data received
# create a composite DF of the data
weather_composite = pd.DataFrame({"Latitude": lat_data, "Temperature (F)": temp_data,
                                 "Humidity (%)": hum_data, "Cloudiness (%)": cld_data,
                                 "Windspeed (mph)": wind_data})

weather_composite.to_csv("received_data.csv")
```


```python

```
